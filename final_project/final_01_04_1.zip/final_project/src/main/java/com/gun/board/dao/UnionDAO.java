package com.gun.board.dao;

import java.util.ArrayList;

import com.gun.board.vo.Union;

public interface UnionDAO {

	ArrayList<Union> getUnion_home()throws Exception;

}
